export { default as Template1Luxury } from "./Template1Luxury";
export { default as Template2Pastel } from "./Template2Pastel";
export { default as Template3Modern } from "./Template3Modern";
export { default as Template4Cosmic } from "./Template4Cosmic";
export { default as Template5Minimal } from "./Template5Minimal";
export { default as Template6Glass } from "./Template6Glass";
