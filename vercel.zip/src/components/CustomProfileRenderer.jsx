import React from "react";
import {
  User,
  Mail,
  Phone,
  MapPin,
  Briefcase,
  GraduationCap,
  Award,
} from "lucide-react";

/**
 * Dynamic Custom Profile Renderer
 * Renders AI-generated custom designs
 */
export default function CustomProfileRenderer({ profileData, customDesign }) {
  if (!profileData || !customDesign) {
    return <div>Loading custom design...</div>;
  }

  const { colorPalette, layout, typography, sections, effects, designConcept } =
    customDesign;
  const {
    name,
    title,
    bio,
    skills,
    experience,
    education,
    email,
    phone,
    aiGeneratedImage,
  } = profileData;

  // Generate dynamic styles
  const pageStyle = {
    backgroundColor: colorPalette.background,
    color: colorPalette.text,
    fontFamily: typography.bodyFont,
    minHeight: "100vh",
  };

  const headingStyle = {
    fontFamily: typography.headingFont,
    color: colorPalette.primary,
  };

  const getSpacingClass = () => {
    switch (layout.spacing) {
      case "compact":
        return "space-y-4";
      case "spacious":
        return "space-y-12";
      default:
        return "space-y-8";
    }
  };

  const getLayoutClass = () => {
    switch (layout.type) {
      case "two-column":
        return "grid md:grid-cols-2 gap-8";
      case "split-screen":
        return "grid lg:grid-cols-2 min-h-screen";
      case "grid":
        return "grid md:grid-cols-3 gap-6";
      case "asymmetric":
        return "grid md:grid-cols-3 gap-6";
      default:
        return "max-w-4xl mx-auto";
    }
  };

  const getAnimationClass = () => {
    if (effects.animations.includes("fade-in")) return "animate-fade-in";
    if (effects.animations.includes("slide-up")) return "animate-slide-up";
    return "";
  };

  // Hero Section Renderer
  const renderHero = () => {
    const heroConfig = sections.hero;

    const getHeroLayout = () => {
      switch (heroConfig.layout) {
        case "split":
          return "grid md:grid-cols-2 gap-8 items-center";
        case "minimal":
          return "text-center py-12";
        case "bold":
          return "text-center py-20";
        default:
          return "text-center py-16";
      }
    };

    const getBackgroundStyle = () => {
      switch (heroConfig.backgroundStyle) {
        case "gradient":
          return {
            background: `linear-gradient(135deg, ${colorPalette.primary}22 0%, ${colorPalette.secondary}22 100%)`,
          };
        case "solid":
          return { backgroundColor: colorPalette.primary + "11" };
        default:
          return {};
      }
    };

    const getImageClass = () => {
      switch (heroConfig.imageStyle) {
        case "circle":
          return "rounded-full";
        case "square":
          return "rounded-none";
        case "blob":
          return "rounded-[40%]";
        default:
          return "rounded-2xl";
      }
    };

    return (
      <section
        className={`${getHeroLayout()} p-8 ${getAnimationClass()}`}
        style={getBackgroundStyle()}
      >
        {heroConfig.showImage && aiGeneratedImage && (
          <div className="flex justify-center">
            <img
              src={aiGeneratedImage}
              alt={name}
              className={`w-48 h-48 object-cover ${getImageClass()} shadow-xl`}
              style={{ borderColor: colorPalette.primary, borderWidth: "4px" }}
            />
          </div>
        )}
        <div>
          <h1 className="text-5xl font-bold mb-4" style={headingStyle}>
            {name}
          </h1>
          <p
            className="text-2xl mb-4"
            style={{ color: colorPalette.secondary }}
          >
            {title}
          </p>
          {bio && <p className="text-lg opacity-80 max-w-2xl mx-auto">{bio}</p>}
        </div>
      </section>
    );
  };

  // About Section Renderer
  const renderAbout = () => {
    if (!bio) return null;

    const aboutConfig = sections.about;

    const getAboutClass = () => {
      switch (aboutConfig.layout) {
        case "card":
          return "bg-white rounded-2xl p-8 shadow-lg";
        case "floating":
          return "bg-white rounded-3xl p-8 shadow-2xl transform hover:scale-105 transition-transform";
        case "sidebar":
          return "border-l-4 pl-6";
        default:
          return "p-6";
      }
    };

    return (
      <section className={`${getAboutClass()} ${getAnimationClass()}`}>
        <h2 className="text-3xl font-bold mb-4" style={headingStyle}>
          About Me
        </h2>
        <p
          className="text-lg leading-relaxed"
          style={{ color: colorPalette.textSecondary }}
        >
          {bio}
        </p>
      </section>
    );
  };

  // Experience Section Renderer
  const renderExperience = () => {
    if (!experience || experience.length === 0) return null;

    const expConfig = sections.experience;

    const getExperienceLayout = () => {
      switch (expConfig.layout) {
        case "timeline":
          return (
            "space-y-6 border-l-4 pl-6" + ` border-[${colorPalette.accent}]`
          );
        case "cards":
          return "grid md:grid-cols-2 gap-6";
        case "grid":
          return "grid md:grid-cols-3 gap-4";
        default:
          return "space-y-6";
      }
    };

    return (
      <section className={getAnimationClass()}>
        <h2 className="text-3xl font-bold mb-6" style={headingStyle}>
          Experience
        </h2>
        <div className={getExperienceLayout()}>
          {experience.map((exp, index) => (
            <div
              key={index}
              className="bg-white rounded-xl p-6 shadow-md hover:shadow-xl transition-shadow"
            >
              <div className="flex items-start gap-3 mb-3">
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center"
                  style={{ backgroundColor: colorPalette.primary + "22" }}
                >
                  <Briefcase
                    className="w-5 h-5"
                    style={{ color: colorPalette.primary }}
                  />
                </div>
                <div className="flex-1">
                  <h3
                    className="font-bold text-lg"
                    style={{ color: colorPalette.primary }}
                  >
                    {exp.role}
                  </h3>
                  <p
                    className="text-sm font-medium"
                    style={{ color: colorPalette.secondary }}
                  >
                    {exp.company}
                  </p>
                  <p className="text-xs opacity-60">{exp.duration}</p>
                </div>
              </div>
              {exp.description && (
                <p
                  className="text-sm"
                  style={{ color: colorPalette.textSecondary }}
                >
                  {exp.description}
                </p>
              )}
            </div>
          ))}
        </div>
      </section>
    );
  };

  // Skills Section Renderer
  const renderSkills = () => {
    if (!skills || skills.length === 0) return null;

    const skillsConfig = sections.skills;

    const getSkillsLayout = () => {
      switch (skillsConfig.layout) {
        case "cloud":
          return "flex flex-wrap gap-3 justify-center";
        case "grid":
          return "grid grid-cols-2 md:grid-cols-4 gap-4";
        case "bars":
          return "space-y-4";
        default:
          return "flex flex-wrap gap-2";
      }
    };

    const renderSkillItem = (skill, index) => {
      if (skillsConfig.layout === "bars") {
        return (
          <div key={index}>
            <p className="text-sm font-medium mb-2">{skill}</p>
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all"
                style={{
                  width: `${85 + Math.random() * 15}%`,
                  backgroundColor: colorPalette.accent,
                }}
              />
            </div>
          </div>
        );
      }

      return (
        <span
          key={index}
          className="px-4 py-2 rounded-full text-sm font-medium shadow-sm hover:shadow-md transition-shadow"
          style={{
            backgroundColor:
              colorPalette.primary +
              (skillsConfig.style === "colorful" ? "22" : "11"),
            color: colorPalette.primary,
          }}
        >
          {skill}
        </span>
      );
    };

    return (
      <section className={getAnimationClass()}>
        <h2 className="text-3xl font-bold mb-6" style={headingStyle}>
          Skills
        </h2>
        <div className={getSkillsLayout()}>
          {skills.map((skill, index) => renderSkillItem(skill, index))}
        </div>
      </section>
    );
  };

  // Education Section Renderer
  const renderEducation = () => {
    if (!education || education.length === 0) return null;

    return (
      <section className={getAnimationClass()}>
        <h2 className="text-3xl font-bold mb-6" style={headingStyle}>
          Education
        </h2>
        <div className="space-y-4">
          {education.map((edu, index) => (
            <div
              key={index}
              className="bg-white rounded-xl p-6 shadow-md flex items-start gap-4"
            >
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0"
                style={{ backgroundColor: colorPalette.secondary + "22" }}
              >
                <GraduationCap
                  className="w-6 h-6"
                  style={{ color: colorPalette.secondary }}
                />
              </div>
              <div>
                <h3
                  className="font-bold text-lg"
                  style={{ color: colorPalette.primary }}
                >
                  {edu.degree}
                </h3>
                <p
                  className="text-sm font-medium"
                  style={{ color: colorPalette.secondary }}
                >
                  {edu.institution}
                </p>
                <p className="text-xs opacity-60">{edu.year}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    );
  };

  // Contact Section Renderer
  const renderContact = () => {
    if (!email && !phone) return null;

    const contactConfig = sections.contact;

    const getContactClass = () => {
      switch (contactConfig.layout) {
        case "cards":
          return "grid md:grid-cols-2 gap-4";
        case "grid":
          return "grid md:grid-cols-3 gap-4";
        default:
          return "flex flex-wrap gap-4 justify-center";
      }
    };

    return (
      <section className={getAnimationClass()}>
        <h2
          className="text-3xl font-bold mb-6 text-center"
          style={headingStyle}
        >
          Get In Touch
        </h2>
        <div className={getContactClass()}>
          {email && (
            <a
              href={`mailto:${email}`}
              className="flex items-center gap-3 p-4 rounded-xl shadow-md hover:shadow-xl transition-all"
              style={{
                backgroundColor: colorPalette.primary + "11",
                color: colorPalette.primary,
              }}
            >
              <Mail className="w-5 h-5" />
              <span className="font-medium">{email}</span>
            </a>
          )}
          {phone && (
            <a
              href={`tel:${phone}`}
              className="flex items-center gap-3 p-4 rounded-xl shadow-md hover:shadow-xl transition-all"
              style={{
                backgroundColor: colorPalette.secondary + "11",
                color: colorPalette.secondary,
              }}
            >
              <Phone className="w-5 h-5" />
              <span className="font-medium">{phone}</span>
            </a>
          )}
        </div>
      </section>
    );
  };

  // Main Render
  return (
    <div style={pageStyle} className="relative overflow-hidden">
      {/* Design Concept Badge (optional) */}
      <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full px-4 py-2 shadow-lg text-xs font-medium">
        <span style={{ color: colorPalette.primary }}>
          ✨ {designConcept?.name || "Custom Design"}
        </span>
      </div>

      {/* Main Content */}
      <div className={`container mx-auto px-4 py-12 ${getLayoutClass()}`}>
        <div className={getSpacingClass()}>
          {/* Render sections in order */}
          {layout.sectionArrangement.map((sectionName, index) => {
            switch (sectionName) {
              case "hero":
                return <div key={index}>{renderHero()}</div>;
              case "about":
                return <div key={index}>{renderAbout()}</div>;
              case "experience":
                return <div key={index}>{renderExperience()}</div>;
              case "skills":
                return <div key={index}>{renderSkills()}</div>;
              case "education":
                return <div key={index}>{renderEducation()}</div>;
              case "contact":
                return <div key={index}>{renderContact()}</div>;
              default:
                return null;
            }
          })}
        </div>
      </div>

      {/* Footer */}
      <div className="text-center py-8 text-sm opacity-60">
        Powered by LinkMe • AI-Generated Custom Design
      </div>
    </div>
  );
}
